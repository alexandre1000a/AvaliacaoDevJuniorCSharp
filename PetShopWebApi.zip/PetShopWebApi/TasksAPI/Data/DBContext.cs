﻿using API.Data.Map;
using API.Models;
using Microsoft.EntityFrameworkCore;
using PetShopWebAPI.Data.Map;
using PetShopWebAPI.Models;

namespace PetShopWebAPI.Data
{
    public class DBContext : DbContext
    {
        public DBContext(DbContextOptions<DBContext> options) : base(options) { 
           //Database.EnsureCreated();   
        }

        public DbSet<AnimalModel> Animais { get; set; }
        public DbSet<UsuarioModel> Usuarios { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AnimalMap());
            modelBuilder.ApplyConfiguration(new UsuarioMap());
            base.OnModelCreating(modelBuilder);
        }
    }
}
