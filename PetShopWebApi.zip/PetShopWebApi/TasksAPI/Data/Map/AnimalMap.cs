﻿using API.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace API.Data.Map
{
    public class AnimalMap : IEntityTypeConfiguration<AnimalModel>
    {
        public void Configure(EntityTypeBuilder<AnimalModel> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Nome).IsRequired().HasMaxLength(255);
            builder.Property(x => x.Idade).IsRequired();
            builder.Property(x => x.Tipo).IsRequired();
            builder.Property(x => x.Raca).IsRequired().HasMaxLength(100);
            builder.Property(x => x.UsuarioId);
            builder.HasOne(x => x.Usuario);

        }
    }
}
