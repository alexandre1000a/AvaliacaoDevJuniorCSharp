﻿using API.Models;
using API.Repositorios.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnimalController : ControllerBase
    {
        private readonly IAnimalRepositorio _animalRepository;
        public AnimalController(IAnimalRepositorio animalRepository)
        {
            _animalRepository = animalRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<AnimalModel>>> GetAll()
        {
            try
            {
                List<AnimalModel> animais = await _animalRepository.GetAnimais();
                return Ok(animais);

            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AnimalModel>> GetOne(int id)
        {
            AnimalModel animal = await _animalRepository.GetAnimalById(id);
            return Ok(animal);
        }

        [HttpPost]
        public async Task<ActionResult<AnimalModel>> Create([FromBody] AnimalModel animalModel)
        {
            AnimalModel animal = await _animalRepository.PostAnimal(animalModel);
            return Ok(animal);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<AnimalModel>> Update([FromBody] AnimalModel animalModel, int id)
        {
            animalModel.Id = id;
            AnimalModel animal = await _animalRepository.PutAnimal(animalModel, id);
            return Ok(animal);

        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<AnimalModel>> Delete(int id)
        {
            bool apagado = await _animalRepository.DeleteAnimal(id);
            return Ok(apagado);

        }

    }
}
