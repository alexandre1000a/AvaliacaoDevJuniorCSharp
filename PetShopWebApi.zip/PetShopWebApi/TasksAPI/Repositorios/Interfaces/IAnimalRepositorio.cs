﻿using API.Models;

namespace API.Repositorios.Interfaces
{
    public interface IAnimalRepositorio
    {
        // get all dos animais 
        Task<List<AnimalModel>> GetAnimais();
        // get one animal
        Task<AnimalModel> GetAnimalById(int id);
        // create animal
        Task<AnimalModel> PostAnimal(AnimalModel animal);
        // update animal
        Task<AnimalModel> PutAnimal(AnimalModel animal, int id);
        // delete animal
        Task<bool> DeleteAnimal(int id);
    }
}
