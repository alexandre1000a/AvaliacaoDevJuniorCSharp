﻿using API.Models;
using API.Repositorios.Interfaces;
using Microsoft.EntityFrameworkCore;
using PetShopWebAPI.Data;

namespace API.Repositorios
{
    public class AnimalRepositorio : IAnimalRepositorio
    {

        private readonly DBContext _dbContext;

        public AnimalRepositorio(DBContext _petShoDBContext)
        {
            _dbContext = _petShoDBContext;
        }

        public async Task<List<AnimalModel>> GetAnimais()
        {
            try
            {
                return await _dbContext.Animais
                .Include(x => x.Usuario)
                .ToListAsync();

            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }

        public async Task<AnimalModel> GetAnimalById(int id)
        {
            return await _dbContext.Animais
                .Include(x => x.Usuario)
                .FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<AnimalModel> PostAnimal(AnimalModel animal)
        {
            await _dbContext.Animais.AddAsync(animal);
            await _dbContext.SaveChangesAsync();
            return animal;
        }

        public async Task<AnimalModel> PutAnimal(AnimalModel animalModel, int id)
        {
            AnimalModel animal = await GetAnimalById(id);
            if (animal == null)
            {
                throw new Exception($"Animal com o ID: {id} não foi encontrado no banco de dados");
            }
            animal.Nome = animalModel.Nome;
            animal.Idade = animalModel.Idade;
            animal.Tipo = animalModel.Tipo;
            animal.Raca = animalModel.Raca;
            animal.UsuarioId = animalModel.UsuarioId;
            animal.Usuario = animalModel.Usuario;


            _dbContext.Animais.Update(animal);
            await _dbContext.SaveChangesAsync();
            return animal;
        }

        public async Task<bool> DeleteAnimal(int id)
        {
            AnimalModel animal = await GetAnimalById(id);
            if (animal == null)
            {
                throw new Exception($"Animal com o ID: {id} não foi encontrado no banco de dados");
            }

            _dbContext.Animais.Remove(animal);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
