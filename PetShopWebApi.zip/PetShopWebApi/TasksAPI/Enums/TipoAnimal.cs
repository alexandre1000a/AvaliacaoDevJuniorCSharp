﻿namespace API.Enums
{
    public enum TipoAnimal
    {
        Gato = 1,
        Cachorro = 2,
    }
}
